﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace MarioGame.Interfaces
{
    public interface IItemState
    {
        void Enter(IItemState state);
        void Exit();
        void CollisionResponse(ICollision collidedCollision);
        void RevealTransition();
        void StandardTransition();
        void Update();
    }
}
