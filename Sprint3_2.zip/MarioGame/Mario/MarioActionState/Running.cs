﻿using System.Runtime.InteropServices;
using MarioGame.Collision;
using MarioGame.Interfaces;
using MarioGame.Mario;
using MarioGame.Mario.MarioActionState;
using Microsoft.Xna.Framework;

namespace MarioGame.MarioActionState
{
    public class Running : ActionState
    {
  
        public Running(MarioEntity mario) : base(mario) { }

        public override void Enter(IMarioActionState preState)
        {
            CurrentState = this;
            PreviousState = preState;
            Mario.Sprite = Mario.Factory.MarioSprite(Mario.PowerState, CurrentState, Mario.Facing, Mario.SpritePosition);
 
                if (Mario.Facing)//right
                {
                    Mario.SpriteVelocity += new Vector2(3, 0);
                }
                else//left
                {
                    Mario.SpriteVelocity += new Vector2(-3, 0);
                }
 
        }

        public override void Down()
        {
            CurrentState.ExitState();
            CurrentState = new Crouching(Mario);
            CurrentState.Enter(this);
           
        }
        public override void GoLeft()
        {

            if (Mario.Facing) //right
            {
                Mario.Facing = false; //left
                CurrentState.Idle();
            }

        }

        public override void GoRight()
        {
            if (!Mario.Facing)//left
            {
                Mario.Facing = true;//right
                CurrentState.Idle();
            }
        }

        public override void Up()
        {
            CurrentState.ExitState();
            CurrentState = new Jumping(Mario);
            CurrentState.Enter(this);
        }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            int MinX = Mario.Sprite.Texture.Width/4;
            int MaxX = Level.ScreenWidth; //- (Mario.sprite.Texture.Width/3);
            if (MaxX < Mario.Sprite.Position.X || MinX > Mario.SpritePosition.X)
                Idle();
            Mario.SpriteVelocity = new Vector2(Mario.SpriteVelocity.X, 1);//gravity
        }

        public override void CollisionResponse(ICollision collided)
        {
            if (!(collided is ItemCollision))
            {
                if (Mario.EntityCollision.TopCollision(collided))
                {
                    Mario.SpriteVelocity = new Vector2(Mario.SpriteVelocity.X, 0);
                }else if (Mario.EntityCollision.SideCollision(collided))
                {
                    Idle();
                }
                
            }
        }
    }
    }

