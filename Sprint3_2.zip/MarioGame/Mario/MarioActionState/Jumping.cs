﻿using System;
using MarioGame.Collision;
using MarioGame.Interfaces;
using MarioGame.MarioActionState;
using Microsoft.Xna.Framework;

namespace MarioGame.Mario.MarioActionState
{
    class Jumping : ActionState
    {
        private int JumpingHeight = 0;
        private static int MaxJumpHeight = 200;

        private static int HeightInc = 5;
        //private double MinJumpVelocity = -0.01;
        //private double MaxJumpVeclocity = -1;

        public Jumping(MarioEntity mario) : base(mario) { }

        public override void Enter(IMarioActionState preState)
        {

            CurrentState = this;
            PreviousState = preState;
            Vector2 velocity = Mario.SpriteVelocity;
            Mario.Sprite =
                Mario.Factory.MarioSprite(Mario.PowerState, CurrentState, Mario.Facing, Mario.SpritePosition);
            Mario.SpriteVelocity = velocity + new Vector2(0, -5);

        }

        public override void ExitState()
        {
            Mario.SpriteVelocity += new Vector2(0, 5);
        }

        public override void GoLeft()
        {

            Mario.SpriteVelocity += new Vector2(-1, 0);

        }

        public override void GoRight()
        {
            Mario.SpriteVelocity += new Vector2(1, 0);
        }

        public override void Down()
        {
            CurrentState.ExitState();
            CurrentState = new Falling(Mario);
            CurrentState.Enter(this);
        }

        public override void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {

            int MinX = 32;
            //Mario.SpriteVelocity += -Mario.MaxVelocity * ((float) gameTime.ElapsedGameTime.TotalMilliseconds / 30);
            //Mario.SpritePosition += Mario.velocity;
            JumpingHeight += HeightInc;
            if (Mario.SpritePosition.X < MinX)
            {
                Mario.SpriteVelocity = new Vector2(0, 3);
                Down();
            }
            if (JumpingHeight > MaxJumpHeight)
            {
                JumpingHeight = 0;
                Down();
            }
        }

        public override void CollisionResponse(ICollision collided)
        {
            if (!(collided is ItemCollision))
            {
                if (Mario.EntityCollision.SideCollision(collided))
                {
                    Mario.SpriteVelocity = new Vector2(0, Mario.SpriteVelocity.Y);
                    Down();
                }
                if (Mario.EntityCollision.BottomCollision(collided))
                {
                    Mario.SpriteVelocity = new Vector2(Mario.SpriteVelocity.X, 0);
                    Down();
                }
                
                

            }
        }
    }
}
