﻿using MarioGame.Collision;
using MarioGame.Interfaces;
using MarioGame.MarioActionState;
using Microsoft.Xna.Framework;


namespace MarioGame.Mario.MarioActionState
{
    public class Falling : ActionState
    {
        public Falling(MarioEntity mario) : base(mario) { }
        public override void Enter(IMarioActionState preState)
        {
            CurrentState = this;
            if (preState is Running)
            {
                PreviousState = preState;
            }
            else//jumping
            {
                PreviousState = preState.PreviousState;
            }
            Velocity = Mario.SpriteVelocity;
            Mario.Sprite = Mario.Factory.MarioSprite(Mario.PowerState, CurrentState, Mario.Facing, Mario.SpritePosition);
            Mario.SpriteVelocity = Velocity + new Vector2(0, 3);
           
        }

        public override void ExitState()
        {
            Mario.SpriteVelocity -= new Vector2(0,3);
        }
       
        //public override void Update(GameTime gameTime,GraphicsDeviceManager graphics)
        //{
        //    Mario.velocity += Mario.MaxVelocity*(float) gameTime.ElapsedGameTime.TotalMilliseconds;
           
        //}

        public override void CollisionResponse(ICollision collided)
        {
            if (!(collided is ItemCollision))
            {
                if (Mario.EntityCollision.SideCollision(collided))
                {
                    Mario.SpriteVelocity = new Vector2(0, Mario.SpriteVelocity.Y);
                }
                if (Mario.EntityCollision.TopCollision(collided))
                {
                    CurrentState.ExitState();
                    CurrentState = PreviousState;
                    CurrentState.Enter(this);
                }
                

            }
        }
    }
}
