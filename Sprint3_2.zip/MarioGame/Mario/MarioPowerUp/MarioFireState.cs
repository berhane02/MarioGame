﻿using MarioGame.Collision;
using MarioGame.Interfaces;

namespace MarioGame.Mario.MarioPowerUp
{
    class MarioFireState : MarioPowerUpState
    {
        public MarioFireState(MarioEntity mario) : base(mario) { }
        public override void Damage()
        {
            StandardTransition();
        }
        public override void StandardTransition()
        {
            CurrentState = new MarioStandardState(Mario);
            CurrentState.Enter(this);
        }

        public override void SuperTransition()
        {
            CurrentState = new MarioSuperState(Mario);
            CurrentState.Enter(this);
        }

        public override void CollisionResponse(ICollision collidedObject)
        {
            if (collidedObject is EnemyCollision && !Mario.EntityCollision.TopCollision(collidedObject))
            {
                Damage();
            }
        }
    }
}
