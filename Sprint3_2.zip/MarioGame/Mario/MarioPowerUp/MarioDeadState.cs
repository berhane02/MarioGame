﻿namespace MarioGame.Mario.MarioPowerUp
{
    class MarioDeadState : MarioPowerUpState
    {
        public MarioDeadState(MarioEntity mario): base(mario) { }

        public override void FireTransition()
        {
            CurrentState = new MarioFireState(Mario);
            CurrentState.Enter(this);
        }

        public override void StandardTransition()
        {
            CurrentState = new MarioStandardState(Mario);
            CurrentState.Enter(this);
        }

        public override void SuperTransition()
        {
            CurrentState = new MarioSuperState(Mario);
            CurrentState.Enter(this);
        }

    }
}
