﻿using MarioGame.Collision;
using MarioGame.Entities;
using MarioGame.Interfaces;

namespace MarioGame.Mario.MarioPowerUp
{
    class MarioStandardState : MarioPowerUpState
    {
        public MarioStandardState(MarioEntity mario) : base(mario) { }
        public override void Damage()
        {
            DeadTransition();
        }

        public override void DeadTransition()
        {
            CurrentState = new MarioDeadState(Mario);
            CurrentState.Enter(this);
        }

        public override void FireTransition()
        {
            CurrentState = new MarioFireState(Mario);
            CurrentState.Enter(this);
        }

        public override void SuperTransition()
        {
            CurrentState = new MarioSuperState(Mario);
            CurrentState.Enter(this);
        }

        public override void CollisionResponse(ICollision collidedObject)
        {
            if (collidedObject.CurrentEntity is RedMushroomEntity || collidedObject.CurrentEntity is FlowerEntity)
            {
                SuperTransition();
            }
            else if (collidedObject is EnemyCollision && !Mario.EntityCollision.TopCollision(collidedObject))
            {
                Damage();
            }
        }
    }
}
