﻿using MarioGame.Entities;
using Microsoft.Xna.Framework;

namespace MarioGame
{
    static class ItemCreation
    {
        public enum ItemType
        {
            Pipe, Flower, Coin,
            RedMushroom, GreenMushroom, Star
        }

        public static Entity BuildItemEntity(ItemType type, Vector2 loc)
        {
            Entity toReturn = null;

            switch (type)
            {
                case ItemType.Pipe:
                    toReturn = new PipeEntity(loc);
                    break;
                case ItemType.Flower:
                    toReturn = new FlowerEntity(loc);
                    break;
                case ItemType.Coin:
                    toReturn = new CoinEntity(loc);
                    break;
                case ItemType.RedMushroom:
                    toReturn = new RedMushroomEntity(loc);
                    break;
                case ItemType.GreenMushroom:
                    toReturn = new GreenMushroomEntity(loc);
                    break;
                case ItemType.Star:
                    toReturn = new StarEntity(loc);
                    break;
                default:
                    break;
            }
            return toReturn;
        }
    }
}

