﻿using MarioGame.Collision;
using MarioGame.Entities;
using MarioGame.Interfaces;
using MarioGame.ItemStateMachine.ItemStates;
using MarioGame.Mario;
using Microsoft.Xna.Framework;
using System;

namespace MarioGame.ItemStateMachine
{
    class JumpingState : ItemState
    {
        public JumpingState(ItemEntity entity, MarioEntity mario) : base(entity) { }
        public override void Enter(IItemState state)
        {
            Vector2 RightVelocity = new Vector2(1, 1);
            Vector2 LeftVelocity = new Vector2(-1, 1);

            if (Item.mario.SpritePosition.X > Item.SpritePosition.X)
            {
                Item.SpriteVelocity = LeftVelocity;
            }
            else
            {
                Item.SpriteVelocity = RightVelocity;
            }

        }

        public override void Exit()
        {
            Item.SpriteVelocity = Vector2.Zero;
        }

        public override void Update()
        {

            Item.SpriteVelocity = new Vector2(Item.SpriteVelocity.X, 1);
        }


        public override void CollisionResponse(ICollision collidedObject)
        {
            if (collidedObject is BlockCollision)
            {
                Rectangle itemBox = Item.BoundBox;
                Rectangle brickBox = collidedObject.CurrentSprite.BoundBox;
                Rectangle intersection = Rectangle.Intersect(itemBox, brickBox);
                if (itemBox.Right > brickBox.Left && intersection.Height > intersection.Width
                    || itemBox.Left > brickBox.Right && intersection.Height > intersection.Width)
                {
                    SideCollision();
                }
                if (itemBox.Bottom > brickBox.Top && intersection.Height < intersection.Width)
                {
                    TopCollision();
                }

            }
            if (collidedObject is MarioCollision)
            {
                Item.Dead = true;
            }


        }

        private void SideCollision()
        {
            Item.SpriteVelocity = new Vector2(Item.SpriteVelocity.X * -1, Item.SpriteVelocity.Y);
        }

        private void TopCollision()
        {
            Vector2 jump = new Vector2(0, -1);

            for(int i = 0; i < 20; i ++)
                Item.SpriteVelocity += jump;
        }


    }
}
