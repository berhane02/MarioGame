﻿using MarioGame.Entities;

namespace MarioGame.ItemStateMachine.ItemStates
{
    class StandardItemState: ItemState
    {
        public StandardItemState(ItemEntity entity) : base(entity) { }
    }
}
