﻿using System;
using MarioGame.Entities;
using MarioGame.Interfaces;
using Microsoft.Xna.Framework;

namespace MarioGame.ItemStateMachine.ItemStates
{
    public class RevealItemState : ItemState
    {
        public RevealItemState(ItemEntity item) : base(item) { }
        public override void Enter(IItemState state)
        {
            Item.SpriteVelocity = new Vector2(0, -1);
        }

        public override void Exit()
        {
            Item.SpriteVelocity = Vector2.Zero;
        }

        public override void Update()
        {
            if (Math.Abs(Item.SpritePosition.Y - Item.InitialPos.Y) > Item.BoundBox.Height)
            {
                CurrentState.Exit();
                if (Item is FlowerEntity)
                {
                    CurrentState = new StandardItemState(Item);
                }
                else if (Item is StarEntity)
                    CurrentState = new JumpingState(Item, Item.mario);
                else
                    CurrentState = new MovingItemState(Item, Item.mario);
                CurrentState.Enter(this);
            }

        }
    }
}
