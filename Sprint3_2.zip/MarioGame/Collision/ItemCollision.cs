﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarioGame.Entities;
using MarioGame.Interfaces;
using Microsoft.Xna.Framework;

namespace MarioGame.Collision
{
    class ItemCollision : Collision
    {
        public ItemCollision(Entity entity) : base(entity)
        {
        }

        public override void Response(ICollision collided)
        {
            CurrentEntity.CollisionResponse(collided);
        }
        
    }
   
}
