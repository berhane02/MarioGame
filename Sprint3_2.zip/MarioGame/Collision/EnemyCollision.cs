﻿using MarioGame.Entities;
using Microsoft.Xna.Framework;
using MarioGame.Mario;
using MarioGame.Mario.MarioPowerUp;
using MarioGame.MarioActionState;
using MarioGame.Interfaces;

namespace MarioGame.Collision
{

    public class EnemyCollision : Collision
    {
        public EnemyCollision(Entity entity) : base(entity)
        {
        }
        public override void Response(ICollision collided)
        {
           
            CurrentEntity.CollisionResponse(collided);
        }

    }
}
