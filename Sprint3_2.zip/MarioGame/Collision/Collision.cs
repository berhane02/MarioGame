﻿using System;
using System.Timers;
using MarioGame.Entities;
using MarioGame.Interfaces;
using Microsoft.Xna.Framework;

namespace MarioGame.Collision
{
    public abstract class Collision : ICollision
    {
        public Entity CurrentEntity { get; set; }
        private const float Delay = 200f;//show for 2 seconds
        private int _elapsed = 0;
        public Sprite CurrentSprite
        {
            get { return CurrentEntity.Sprite; }
            set { CurrentEntity.Sprite = value; }
        }

        public Vector2 FutureLocation
        {
            get { return CurrentEntity.SpritePosition + CurrentEntity.SpriteVelocity; }
        }
        public Rectangle FutureBox
        {
            get { return CurrentSprite.FutureBox(FutureLocation);}
        }
        public Rectangle Intersection { get; set; }
        protected Collision(Entity entity)
        {
            CurrentEntity = entity;
        }
        public virtual void Detection(GameTime gameTime, ICollision collideObject) //detect IF it will collide.
        {
            if (FutureBox.Intersects(collideObject.CurrentEntity.BoundBox))
            {
                Intersection = Rectangle.Intersect(FutureBox, collideObject.CurrentSprite.BoundBox);
                collideObject.Response(this); //the other collided entity response.
                Response(collideObject); //current entity response
                CurrentSprite.CollisionResponse(true); //tint sprite
                collideObject.CurrentSprite.CollisionResponse(true); //tint sprite
            }
           
            _elapsed += gameTime.ElapsedGameTime.Milliseconds;
            if (_elapsed >= Delay)//To show a black color for collision response.
            {
                CurrentSprite.CollisionResponse(false);
                collideObject.CurrentSprite.CollisionResponse(false);
                _elapsed = 0;
            }
        }

        public virtual bool MarioState() { return false; }

        public virtual void Response(ICollision collided){}//base response is to do nothing.

        //when currentSprite hit the top of collided object
        public bool TopCollision(ICollision collided) //currentSprite on top.
        {
            return Intersection.Bottom <= collided.FutureBox.Bottom && Intersection.Top >= FutureBox.Top&&CurrentEntity.SpriteVelocity.Y>0;
        }

        //when currentSprite hit the bottom of collided object
        public bool BottomCollision(ICollision collided)
        {
            return Intersection.Top >= collided.FutureBox.Top && Intersection.Bottom <= FutureBox.Bottom&&CurrentEntity.SpriteVelocity.Y<0;
        }

        public bool SideCollision(ICollision collided) //current sprite moving L or R.
        {
            //return ((Intersection.Left > FutureBox.Left && Intersection.Right < collided.FutureBox.Right&&FutureBox.Right>collided.FutureBox.Left) ||
            //        (Intersection.Left < FutureBox.Left && Intersection.Right > collided.FutureBox.Right&&FutureBox.Left>collided.FutureBox.Right)) &&
            //       !(CurrentSprite.Velocity.X == 0.0);
            return Intersection.Width <= Intersection.Height && CurrentEntity.SpriteVelocity.X !=0;
        }
    }
}
