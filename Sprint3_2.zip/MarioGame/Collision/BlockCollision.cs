﻿using MarioGame.Entities;
using MarioGame.Interfaces;
using MarioGame.Block;
using Microsoft.Xna.Framework;

namespace MarioGame.Collision
{
    public class BlockCollision : Collision
    {
        public BlockCollision(Entity block) : base(block) { }

        public override void Response(ICollision collided)
        {
            CurrentEntity.CollisionResponse(collided);
        }
        public void ItemCollision(ItemEntity item)
        {
            Vector2 leftVelocity = new Vector2(-1, 0);
            Vector2 rightVelocity = new Vector2(1, 0);
            if (item.SpriteVelocity == leftVelocity)
            {
                item.SpriteVelocity = rightVelocity;
            }
            else
                item.SpriteVelocity = leftVelocity;
        }

        public void GoombaCollisionResponse(GoombaEntity goomba)
        {
             
        }
    }
}
