﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MarioGame
{
    public class SceneSprite : Sprite
    {
        public SceneSprite(Texture2D texture, Vector2 loc) : base(texture, false, 1, 1, loc) {}
        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Texture, new Rectangle((int)Position.X, (int)Position.Y, Scale * Width, Scale * Height), Tint);
        }
    
    }
    public class BigMountain : SceneSprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Scene/bigmountain");
        public BigMountain(Vector2 loc) : base(texture, loc) { Scale = 5; }
    }

    public class SmallMountain : SceneSprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Scene/smallmountain");
        public SmallMountain(Vector2 loc) : base(texture,  loc) { Scale = 4; }
    }

    public class OneGrass : SceneSprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Scene/onegrass");
        public OneGrass(Vector2 loc) : base(texture, loc) { Scale = 4; }
    }

    public class TwoGrass : SceneSprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Scene/twograss");
        public TwoGrass(Vector2 loc) : base(texture,loc) { Scale = 4; }
    }

    public class ThreeGrass : SceneSprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Scene/threegrass");
        public ThreeGrass(Vector2 loc) : base(texture, loc) { Scale = 4; }
    }

    public class SingleCloud : SceneSprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Scene/singlecloud");
        public SingleCloud(Vector2 loc) : base(texture, loc) { }
    }

    public class DoubleCloud : SceneSprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Scene/doublecloud");
        public DoubleCloud(Vector2 loc) : base(texture, loc) { }
    }

    public class TripleCloud : SceneSprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Scene/triplecloud");
        public TripleCloud(Vector2 loc) : base(texture, loc) { }
    }

}