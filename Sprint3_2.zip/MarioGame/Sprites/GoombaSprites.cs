﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MarioGame
{
    public class WalkingGoomba : Sprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Enemy/Goomba");
        public static Vector2 Location { get; set; }

        public WalkingGoomba(Vector2 loc) : base(texture, true, 1, 3, loc)
        {
            Location = loc;
            Box = Color.Red;
            Dead = false;
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            int row = CurrentFrame / Columns;
            int column = CurrentFrame % Columns;

            Rectangle sourceRectangle = new Rectangle(Width * column, Height * row, Width, Height);
            Rectangle destinationRectangle = new Rectangle((int)Position.X, (int)Position.Y, Width, Height);
            BoundBox = new Rectangle((int)Position.X, (int)Position.Y, Width, Height);

            if (this.IsToggle && !Dead)
            {
                spriteBatch.Draw(Rectangle, BoundBox, Box); //try to draw rectangle as background for sprite
            }
            if (!Dead)
            {
                spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Tint, 0, Vector2.Zero, SpriteEffects.None, 0.2f);
            }
            else
            {
                BoundBox = new Rectangle(0, 0, 0, 0);
            }
        }


        public override void Update(GameTime gametime, Vector2 velocity, GraphicsDeviceManager graphics)
        {
            WhiteBox(graphics);
            double timePerFrame = 0.2;
            CurrentFrame = (int)(gametime.TotalGameTime.TotalSeconds / timePerFrame);
            CurrentFrame = CurrentFrame % TotalFrames;

            if (CurrentFrame == 1)
            {
                CurrentFrame = 0;
            }
            else
            {
                CurrentFrame = 1;
            }
            Velocity = velocity;
            Position += Velocity;

        }

    }


}