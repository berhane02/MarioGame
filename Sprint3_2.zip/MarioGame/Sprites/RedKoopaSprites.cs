﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MarioGame
{

    public class RedKoopaWalkingLeft : Sprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Enemy/RightRedkoopa");

        public RedKoopaWalkingLeft(Vector2 loc) : base(texture, true, 1, 4, loc) { Box = Color.Red; Dead = false; }
        public override void Update(GameTime gametime, Vector2 velocity, GraphicsDeviceManager graphics)
        {
            WhiteBox(graphics);
            double timePerFrame = 0.2;
            CurrentFrame = (int)(gametime.TotalGameTime.TotalSeconds / timePerFrame);
            CurrentFrame = CurrentFrame % TotalFrames;

            Velocity = velocity;
            Position += Velocity;

        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            int width = Texture.Width / Columns;
            int height = Texture.Height / Rows;

            int row;
            int column;
            if (CurrentFrame % 2 == 1)
            {
                row = 1 / Columns;
                column = 4 % Columns;
            }
            else
            {
                row = 3 / Columns;
                column = 3 % Columns;
            }

            Rectangle sourceRectangle = new Rectangle(width * column, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)Position.X, (int)Position.Y, width, height);
            BoundBox = destinationRectangle;

            if (this.IsToggle && !Dead)
            {
                spriteBatch.Draw(Rectangle, BoundBox, Box);
            }
            if (!Dead)
                spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Tint, 0, Vector2.Zero, SpriteEffects.None, 0.2f);
        }

    }

    public class RedKoopaWalkingRight : Sprite
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Enemy/LeftRedkoopa");

        public RedKoopaWalkingRight(Vector2 loc) : base(texture, true, 1, 4, loc)
        {
            Box = Color.Red; Dead = false;
        }
        public override void Update(GameTime gametime, Vector2 velocity, GraphicsDeviceManager graphics)
        {
            WhiteBox(graphics);
            double timePerFrame = 0.2;
            CurrentFrame = (int)(gametime.TotalGameTime.TotalSeconds / timePerFrame);
            CurrentFrame = CurrentFrame % TotalFrames;

            Velocity = velocity;
            Position += Velocity;
        }
        public override void Draw(SpriteBatch spriteBatch)
        {

            int width = Texture.Width / Columns;
            int height = Texture.Height / Rows;

            int row;
            int column;
            if (CurrentFrame % 2 == 1)
            {
                row = 4 / Columns;
                column = 4 % Columns;
            }
            else
            {
                row = 5 / Columns;
                column = 5 % Columns;
            }

            Rectangle sourceRectangle = new Rectangle(width * column, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)Position.X, (int)Position.Y, width, height);
            BoundBox = destinationRectangle;
            if (this.IsToggle && !Dead)
            {
                spriteBatch.Draw(Rectangle, BoundBox, Box); //try to draw rectangle as background for sprite
            }
            if (!Dead)
                spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Tint, 0, Vector2.Zero, SpriteEffects.None, 0.2f);
        }

    }

}