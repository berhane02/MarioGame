﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MarioGame
{
    public class BlockSprites : Sprite
    {
        protected BlockSprites(Texture2D texture, bool animated, int row, int column, Vector2 loc) : base(texture, animated, row, column, loc)
        {
            SeriesPicture = animated;
            Rows = row;
            Columns = column;
            CurrentFrame = 0;
            TotalFrames = Rows * Columns;
            Texture = texture;
            Position = loc;
            Velocity = Vector2.Zero;
            Scale = 2;
            Tint = Color.White;
            Box = Color.Blue;
            BoundBox = new Rectangle((int)loc.X - 5, (int)loc.Y - 5, Scale * Width + 10, Scale * Height + 10);
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            int row = CurrentFrame / Columns;
            int column = CurrentFrame % Columns;

            Rectangle sourceRectangle = new Rectangle(Width * column, Height * row, Width, Height);
            Rectangle destinationRectangle = new Rectangle((int)Position.X, (int)Position.Y, Scale * Width, Scale * Height);
            BoundBox = new Rectangle((int)Position.X - 5, (int)Position.Y - 5, Scale * Width + 10, Scale * Height + 10);//bounding box for blocks are bigger
            if (this.IsToggle)
            {
                spriteBatch.Draw(Rectangle, BoundBox, Box); //try to draw rectangle as background for sprite
            }
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Tint,0,Vector2.Zero,SpriteEffects.None,0.1f);
        }
    }
    public class ExplodingBlock : BlockSprites//a shard
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Block/BrickBlock");

        public ExplodingBlock(Vector2 loc) : base(texture, false, 1, 2, loc)
        {
            CurrentFrame = 0;
            TotalFrames = Rows * Columns;
            Texture = texture;
            Position = loc;
            Velocity = Vector2.Zero;
            Scale = 1;
            Tint = Color.White;
            Box = Color.Blue;
            BoundBox = new Rectangle((int)loc.X - 5, (int)loc.Y - 5, Scale * Width + 10, Scale * Height + 10);
        }

    }

    public class BrickBlock : BlockSprites
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Block/BrickBlock");
        public BrickBlock(Vector2 loc) : base(texture, false, 1, 2, loc) { }

    }
    public class HiddenBlock : BlockSprites
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Block/BrickBlock");

        public HiddenBlock(Vector2 loc) : base(texture, false, 1, 2, loc) { }
        public override void Draw(SpriteBatch spriteBatch)
        {
            //if hidden we don't draw the sprite but we need the bounding box
            BoundBox = new Rectangle((int)Position.X - 5, (int)Position.Y - 5, Scale * Width + 10, Scale * Height + 10);//bounding box for blocks are bigger
            if (this.IsToggle)
            {
                spriteBatch.Draw(Rectangle, BoundBox, Box);
            }
        }
    }
    public class FloorBlock : BlockSprites
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Block/FloorBlock");
        public FloorBlock(Vector2 loc) : base(texture, false, 1, 1, loc) { }
    }

    public class QuestionBlock : BlockSprites
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Block/QuestionBlocks");
        public QuestionBlock(Vector2 loc) : base(texture, true, 1, 3, loc) { }

    }

    public class StairBlock : BlockSprites
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Block/StairBlock");
        public StairBlock(Vector2 loc) : base(texture, false, 1, 1, loc) { }
    }

    public class UsedBlock : BlockSprites
    {
        static Texture2D texture = Game1.ContentLoad.Load<Texture2D>("Block/UsedBlock");
        public UsedBlock(Vector2 loc) : base(texture, false, 1, 1, loc) { }
    }


}