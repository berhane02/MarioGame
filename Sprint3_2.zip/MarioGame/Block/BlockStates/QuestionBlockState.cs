﻿using MarioGame.Collision;
using MarioGame.Entities;
using MarioGame.Interfaces;
using MarioGame.Mario;

namespace MarioGame.Block.BlockStates
{
    public class QuestionBlockState : BlockState
    {
        public QuestionBlockState(BlockEntity block) : base(block) { }
        public override void Enter(IBlockState previousState)
        {
            CurrentState = this;
            Block.Sprite = Block.Factory.BuildSprite(Block.Factory.FindType(this), Block.SpritePosition);
        }

        public override void CollisionResponse(ICollision collidedObject)
        {
            if (collidedObject is MarioCollision && collidedObject.BottomCollision(Block.EntityCollision))
            {
                BumpTransition();
                if (Block.Items != null && Block.Items.Count > 0)//reveal item
                {
                    Entity item = Block.Items[0];
                    Block.Items.RemoveAt(0);
                    Tile tile = new Tile {Entity = item};
                    Block.CollideList.Add(tile);
                    Block.MovingEntities.Add(tile.Entity);
                    item.Reveal(collidedObject.CurrentEntity as MarioEntity);
                }
            }
        }

        public override void BumpTransition()
        {
            CurrentState.ExitState();
            CurrentState = new QuestionBlockBumpState(Block);
            CurrentState.Enter(this);
        }

    }
}
