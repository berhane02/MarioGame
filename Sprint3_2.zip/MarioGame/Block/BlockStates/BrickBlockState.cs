﻿using MarioGame.Collision;
using MarioGame.Entities;
using MarioGame.Interfaces;
using MarioGame.Mario;

namespace MarioGame.Block.BlockStates
{
    public class BrickBlockState : BlockState
    {
        public BrickBlockState(BlockEntity block) : base(block) { }
        public override void BumpTransition()
        {
            CurrentState.ExitState();
            CurrentState = new BrickBlockBumpState(Block);
            CurrentState.Enter(this);
        }

        public override void ExplodeTransition()
        {
            CurrentState.ExitState();
            CurrentState = new ExplodingBlockState(Block);
            CurrentState.Enter(this);
        }

        public override void CollisionResponse(ICollision collidedObject)
        {
            if (collidedObject.MarioState()&&collidedObject.BottomCollision(Block.EntityCollision))
            {
                ExplodeTransition();
            }
            else if (collidedObject is MarioCollision && collidedObject.BottomCollision(Block.EntityCollision))
            {
                BumpTransition();
                if (Block.Items != null && Block.Items.Count > 0)//reveal item
                {
                    Entity item = Block.Items[0];
                    Block.Items.RemoveAt(0);
                    Tile tile = new Tile
                    {
                        Entity = item
                    };
                    Block.CollideList.Add(tile);
                    Block.MovingEntities.Add(tile.Entity);
                    item.Reveal(collidedObject.CurrentEntity as MarioEntity);
                }
            }
        }

    }
}
