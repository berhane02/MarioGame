﻿using MarioGame.Block.BlockStates;
using MarioGame.Entities;
using Microsoft.Xna.Framework;


namespace MarioGame.Block
{
    public class HiddenBlockState : BlockState
    {

        public HiddenBlockState(BlockEntity block) : base(block) { }
      
        public override void BumpTransition()
        {
            CurrentState.ExitState();
            CurrentState = new BrickBlockBumpState(Block);
            CurrentState.Enter(this);
        }
    }
}
