﻿using Microsoft.Xna.Framework;
using MarioGame;
using System;
using MarioGame.Entities;

namespace MarioGame.Factory
{
    public static class EnemyFactory
    {

        public enum EnemyType
        {
            WalkingGoomba,
            GreenKoopaWalkingLeft, GreenKoopaWalkingRight,
            RedKoopaWalkingLeft, RedKoopaWalkingRight,
        }
        
        public static Entity BuildEnemySprite(EnemyType type, Vector2 loc)
        {
            Entity toReturn = null;
            
            switch (type)
            {
                case EnemyType.WalkingGoomba:
                    toReturn = new GoombaEntity(loc);
                    break;
                case EnemyType.GreenKoopaWalkingLeft:
                    toReturn = new GreenKoopaEntity(loc,true);
                    break;
                case EnemyType.GreenKoopaWalkingRight:
                    toReturn = new GreenKoopaEntity(loc,false);
                    break;
                case EnemyType.RedKoopaWalkingLeft:
                    toReturn = new RedKoopaEntity(loc,true);
                    break;
                case EnemyType.RedKoopaWalkingRight:
                    toReturn = new RedKoopaEntity(loc,false);
                    break;
                default:
                    break;
            }
            return toReturn;
        }
    }
}
