﻿using MarioGame.CommandHandling;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MarioGame
{
    /// <summary>
    /// This is the main type.
    /// </summary>
    public class Game1 : Game
    {
        readonly GraphicsDeviceManager _graphics;
        SpriteBatch _spriteBatch;
        public static ContentManager ContentLoad { get; set; }
        private Level level;
        public Level Level0
        {
            get { return level; }
        }
        private Background background;
        public Controller KeyBoardControls { get; set; }
        public Controller GamePadControls { get; set; }

        Camera camera;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            ContentLoad = Content;
            IsMouseVisible = true;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
            KeyBoardControls = new KeyBoardControls(this);
            GamePadControls = new GamePadControls(this);

        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            level = new Level(_graphics);
            background = new Background(_spriteBatch, _graphics);
            camera = new Camera(GraphicsDevice.Viewport);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            level.Update(gameTime);
            KeyBoardControls.UpdateInput();
            GamePadControls.UpdateInput();
            camera.Update(level.Mario.SpritePosition, Level.ScreenWidth, Level.ScreenHeight);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            _spriteBatch.Begin(SpriteSortMode.BackToFront,
                                null,
                                SamplerState.LinearWrap,
                                null, null, null,
                                camera.Transform);
            background.Draw();
            level.Draw(_spriteBatch);
            _spriteBatch.End();
            base.Draw(gameTime);
        }
        public void ExitCommand()
        {
            Exit();
        }

        public void Reset()
        {
            level = new Level(_graphics);
            KeyBoardControls = new KeyBoardControls(this);
            GamePadControls = new GamePadControls(this);
        }

    }
}
