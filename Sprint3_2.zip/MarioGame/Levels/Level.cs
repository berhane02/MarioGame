﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using System.IO;
using Microsoft.Xna.Framework.Graphics;
using MarioGame.Block;
using System.Collections.ObjectModel;
using MarioGame.Entities;
using MarioGame.Factory;
using MarioGame.Mario;

namespace MarioGame
{
    public class Tile
    {
        public Entity Entity { get; set; }
        public Vector2 Position { get; set; }
    }

    public class Level
    {
        bool toToggle = false;
        private const float Rewrite = 2000f;
        private List<Tile> tiles = new List<Tile>();
        private List<Entity> movingEntities = new List<Entity>();
        private GraphicsDeviceManager Graphics { get; set; }
        public static int ScreenWidth;
        public static int ScreenHeight;
        //mario
        public MarioEntity Mario { get; set; }

        public Level(GraphicsDeviceManager _graphics)
        {
            Graphics = _graphics;
            using (var reader = new StreamReader(@"level1.csv"))
            {
                reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    Tile tile = new Tile();
                    string n = values[0];
                    int x = Convert.ToInt32(values[1]);
                    int y = Convert.ToInt32(values[2]);
                    tile.Position = new Vector2(x, y);
                    string itemName = "";
                    int itemNum = 0;
                    if (values.Length > 3 && !values[3].Equals(""))
                    {
                        itemName = values[3];
                        itemNum = Convert.ToInt32(values[4]);
                    }

                    //Find Type
                    if (n.Equals("WindowsSize"))
                    {
                        ScreenWidth = x;  // set this value to the desired width of your window
                        ScreenHeight = y;   // set this value to the desired height of your window
                    }
                    else if (n.Equals("Mario"))
                    {
                        Mario = new MarioEntity(tile.Position);
                        movingEntities.Add(Mario);
                    }
                    else if (Enum.TryParse(n, out ItemCreation.ItemType itemType))
                    {
                        tile.Entity = ItemCreation.BuildItemEntity(itemType, tile.Position);
                    }
                    else if (Enum.TryParse(n, out Factory.EnemyFactory.EnemyType enemyType))
                    {
                        tile.Entity = Factory.EnemyFactory.BuildEnemySprite(enemyType, tile.Position);
                        movingEntities.Add(tile.Entity);
                    }
                    else if (Enum.TryParse(n, out BlockCreation.SceneBlock sceneBlock))
                    {
                        tile.Entity = BlockCreation.BuildSceneBlock(sceneBlock, tile.Position);
                    }
                    else if (Enum.TryParse(n, out BlockCreation.Blocks blockType))
                    {
                        tile.Entity = BlockCreation.BuildBlockEntity(blockType, tile.Position);
                        if ((tile.Entity is QuestionBlockEntity || tile.Entity is BrickBlockEntity)
                            && (Enum.TryParse(itemName, out ItemCreation.ItemType item)))//adding item to question block entity
                        {
                            Entity one = ItemCreation.BuildItemEntity(item, tile.Position);
                            tile.Entity.AddItems(one, itemNum, tiles, movingEntities);
                        }
                    }
                    if (tile.Entity != null)
                        tiles.Add(tile);
                }
            }
        }
        public void Update(GameTime gameTime)
        {
            //Collision Detection
            for (int i = 0; i < movingEntities.Count; i++)
            {
                for (int j = 0; j < tiles.Count; j++)
                {
                    if (tiles[j].Entity.EntityCollision != null && movingEntities[i] != tiles[j].Entity)
                        movingEntities[i].EntityCollision.Detection(gameTime, tiles[j].Entity.EntityCollision);

                }
            }

            for (int j = 0; j < tiles.Count; j++)//this will allow for adding a new item entity to the mix
            {
                if (tiles[j].Entity.Dead)
                {
                    if (movingEntities.Contains(tiles[j].Entity))
                        movingEntities.Remove(tiles[j].Entity);
                    tiles.RemoveAt(j);
                }
                else
                    tiles[j].Entity.Update(gameTime, Vector2.Zero, Graphics);
            }
            Console.WriteLine(Mario.SpriteVelocity);

            Mario.Update(gameTime, Graphics);
        }
        public void Draw(SpriteBatch spriteBatch)
        {

            foreach (Tile tile in tiles)
                tile.Entity.Draw(spriteBatch);
            Mario.Draw(spriteBatch);

        }
        public void ToggleCommand()
        {
            if (!toToggle)
            {
                toToggle = true;
                foreach (Tile tile in tiles)
                {
                    tile.Entity.Sprite.IsToggle = true;
                }
                Mario.Sprite.IsToggle = true;
            }
            else
            {
                toToggle = false;
                foreach (Tile tile in tiles)
                {
                    tile.Entity.Sprite.IsToggle = false;
                }
                Mario.Sprite.IsToggle = false;
            }
        }


    }

}
