﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarioGame
{
    public class Background
    {
        private SpriteBatch spriteBatch;
        private GraphicsDeviceManager graphics;
        private Vector2 camera;
        private RenderTarget2D _renderTarget2;
        private RenderTarget2D _renderTarget1;
        private Point _dimension;

        public Background(SpriteBatch theSpriteBatch, GraphicsDeviceManager theGraphics)
        {
            camera = Camera.center;
            this.spriteBatch = theSpriteBatch;
            this.graphics = theGraphics;
            _dimension = new Point(Level.ScreenHeight*800/480,Level.ScreenHeight);

            List<SceneSprite> layer1 = new List<SceneSprite>();
            List<SceneSprite> layer2 = new List<SceneSprite>();

            layer1.Add(new SmallMountain(new Vector2(100,_dimension.Y - 19 * 4)));
            layer1.Add(new OneGrass(new Vector2(400, _dimension.Y - 16 * 4)));
            layer1.Add(new SingleCloud(new Vector2(200,100)));
            layer1.Add(new DoubleCloud(new Vector2(100,200)));
            layer1.Add(new TripleCloud(new Vector2(400,50)));

            layer2.Add(new BigMountain(new Vector2(50, _dimension.Y - 35 * 5)));
            layer2.Add(new TwoGrass(new Vector2(600, _dimension.Y - 16 * 4)));
            layer2.Add(new ThreeGrass(new Vector2(300, _dimension.Y - 16 * 4)));
            layer2.Add(new SingleCloud(new Vector2(150, 240)));
            layer2.Add(new DoubleCloud(new Vector2(450, 50)));
            layer2.Add(new TripleCloud(new Vector2(600, 120)));

            // Create Render Target
            if (_renderTarget1 == null)
                _renderTarget1 = new RenderTarget2D(graphics.GraphicsDevice, _dimension.X, _dimension.Y);
            if (_renderTarget2 == null)
                _renderTarget2 = new RenderTarget2D(graphics.GraphicsDevice, _dimension.X, _dimension.Y);

            graphics.GraphicsDevice.SetRenderTarget(_renderTarget1);

            graphics.GraphicsDevice.Clear(Color.Transparent);

            spriteBatch.Begin();
            foreach (SceneSprite sprite in layer1)
            {
                sprite.Draw(spriteBatch);
            }
            spriteBatch.End();

            graphics.GraphicsDevice.SetRenderTarget(null);

            graphics.GraphicsDevice.SetRenderTarget(_renderTarget2);

            graphics.GraphicsDevice.Clear(Color.Transparent);

            spriteBatch.Begin();
            foreach (SceneSprite sprite in layer2)
            {
                sprite.Draw(spriteBatch);
            }
            spriteBatch.End();

            // Reset the device to the back buffer
            graphics.GraphicsDevice.SetRenderTarget(null);

        }
        

        public void Draw()
        {

            // Now Tile RenderTarget across ViewPort
            Viewport _viewport = graphics.GraphicsDevice.Viewport;
            int _tilesX = 1;
            while ((_dimension.X * _tilesX) <= _viewport.Width)
                _tilesX++;
            _tilesX++;
            for (int _tileX = 0; _tileX < _tilesX; _tileX++)
                spriteBatch.Draw((Texture2D)_renderTarget2, new Vector2(_tileX * _dimension.X, 0), new Rectangle((int)(Camera.center.X * 0.2f), 0, _dimension.X, _dimension.Y), Color.White, 0, Vector2.Zero, Vector2.One, SpriteEffects.None, 0.4f);
            for (int _tileX = 0; _tileX < _tilesX; _tileX++)
                spriteBatch.Draw((Texture2D)_renderTarget1, new Vector2(_tileX * _dimension.X, 0), new Rectangle((int)(Camera.center.X * 0.5f), 0, _dimension.X, _dimension.Y), Color.White, 0, Vector2.Zero, Vector2.One, SpriteEffects.None, 0.3f);
            
        }
    }
}
