﻿using MarioGame.Collision;
using MarioGame.Factory;
using MarioGame.Interfaces;
using MarioGame.ItemStateMachine.ItemStates;
using MarioGame.Mario;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MarioGame.Entities
{
    public abstract class ItemEntity : Entity
    {
        public Vector2 InitialPos { get; set; }
        public IItemState State { get; set; }
        protected ItemEntity(Vector2 loc) { }
        public override void Reveal(MarioEntity Mario)
        {
            mario = Mario;
            State.RevealTransition();
        }

        public override void Update(GameTime gametime, Vector2 velocity, GraphicsDeviceManager graphics)
        {
            Sprite.Update(gametime,SpriteVelocity,graphics);
            State.Update();
        }

        public override void CollisionResponse(ICollision collided)
        {
            State.CollisionResponse(collided);
        }
    }

    public class FlowerEntity : ItemEntity
    {
        public FlowerEntity(Vector2 loc):base(loc)
        {
            InitialPos = loc;
            Sprite = new Flower(loc);
            EntityCollision = new ItemCollision(this);
            State = new StandardItemState(this);
        }
    }
    public class CoinEntity: ItemEntity
    {
        public CoinEntity(Vector2 loc) : base(loc)
        {
            InitialPos = loc;
            Sprite = new Coin(loc);
            EntityCollision = new ItemCollision(this);
            State = new StandardItemState(this);
        }
    }
    public class RedMushroomEntity: ItemEntity
    {
        public RedMushroomEntity(Vector2 loc) : base(loc)
        {
            InitialPos = loc;
            Sprite = new RedMushroom(loc);
            EntityCollision = new ItemCollision(this);
            State = new StandardItemState(this);
        }
    }

    public class GreenMushroomEntity: ItemEntity
    {
        public GreenMushroomEntity(Vector2 loc) : base(loc)
        {
            InitialPos = loc;
            Sprite = new GreenMushroom(loc);
            EntityCollision = new ItemCollision(this);
            State = new StandardItemState(this);
        }
    }
    
    public class StarEntity : ItemEntity
    {
        public StarEntity(Vector2 loc) : base(loc)
        {
            InitialPos = loc;
            Sprite = new Star(loc);
            EntityCollision = new ItemCollision(this);
            State = new StandardItemState(this);
        }
    }

    public class PipeEntity : ItemEntity
    {
        public PipeEntity(Vector2 loc) : base(loc)
        {
            Sprite = new Pipe(loc);
            EntityCollision = new BlockCollision(this);
            State = new StandardItemState(this);
        }
    }


}