﻿using MarioGame.Block.BlockStates;
using MarioGame.Collision;
using MarioGame.Entities;
using MarioGame.Factory;
using Microsoft.Xna.Framework;

namespace MarioGame.Block
{
    class BrickBlockEntity:BlockEntity
    {
        public BrickBlockEntity(Vector2 loc) : base(loc)
        {
            Factory = new BlockFactory();
            BState = new BrickBlockState(this);
            Sprite = Factory.BuildSprite(Factory.FindType(BState), loc);
            BState.Enter(null);
            SpritePosition = loc;
            InitialPos = loc;
            EntityCollision = new BlockCollision(this);
        }
    }
}
