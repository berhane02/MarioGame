﻿using System;
using MarioGame.Collision;
using MarioGame.Entities;
using MarioGame.Factory;
using MarioGame.Interfaces;
using MarioGame.Mario.MarioActionState;
using MarioGame.Mario.MarioPowerUp;
using MarioGame.MarioActionState;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MarioGame.Mario
{
    public class MarioEntity : Entity
    {
        public IMarioActionState ActionState { get; set; }
        public IMarioPowerUpState PowerState { get; set; }
        public MarioFactory Factory { get; set; }
        public bool Facing { get; set; } //left false; right true
        public Vector2 MaxVelocity = new Vector2(0, -0.00005f);
        public Vector2 MinVelocity = new Vector2(-3, -1.5f);
        public Vector2 velocity;
        
        public MarioEntity(Vector2 location)
        {
            Factory = new MarioFactory();
            PowerState = new MarioStandardState(this);
            ActionState = new Idling(this);
            Facing = true;
            Sprite = Factory.MarioSprite(PowerState, ActionState, Facing, location);
            SpritePosition = location;
            SpriteVelocity = new Vector2(0, 0);
            EntityCollision = new MarioCollision(this);
        }

        public override void CollisionResponse(ICollision collidedObject)
        {
            PowerState.CollisionResponse(collidedObject);
            ActionState.CollisionResponse(collidedObject);
        }
        public void TakeDamage()
        {
            PowerState.Damage();
        }

        public void Standard()
        {
            PowerState.StandardTransition();
        }
        
        public void Super()
        {
            PowerState.SuperTransition();
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")]
        public void Fire()
        {
            PowerState.FireTransition();
        }
        public void Up()
        {
            ActionState.Up();
        }
        public void Down()
        {
            ActionState.Down();
        }

        public void Left()
        {
            ActionState.GoLeft();
        }
        public void Right()
        {
            ActionState.GoRight();
            
        }

        public void Idle()
        {
            ActionState.Idle();
        }

        public void Update(GameTime gameTime, GraphicsDeviceManager graphics)
        {
            if (ActionState is Running && SpriteVelocity.Y > 0)
            {
                ActionState.Falling();
            }
            Sprite.Update(gameTime, SpriteVelocity, graphics);
            ActionState.Update(gameTime,graphics);
        }



    }
}
