﻿using MarioGame.Block.BlockStates;
using MarioGame.Collision;
using MarioGame.Entities;
using MarioGame.Factory;
using Microsoft.Xna.Framework;

namespace MarioGame.Block
{
    class UsedBlockEntity : BlockEntity
    {
        public UsedBlockEntity(Vector2 loc) : base(loc)
        {
            Factory = new BlockFactory();
            BState = new UsedBlockState(this);
            Sprite = Factory.BuildSprite(Factory.FindType(BState), loc);
            BState.Enter(null);
            SpritePosition = loc;
            InitialPos = loc;
            EntityCollision = new BlockCollision(this);
        }
    }
}
