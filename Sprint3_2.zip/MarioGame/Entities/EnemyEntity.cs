﻿using Microsoft.Xna.Framework;
using MarioGame.Collision;
using MarioGame.Interfaces;

namespace MarioGame.Entities
{
    public abstract class EnemyEntity : Entity
    {

        public bool IsLeft { get; set; }
        private Rectangle camera;
        private bool started;
        protected EnemyEntity(Vector2 loc)
        {
            started = false;
        }

        public override void Update(GameTime gametime, Vector2 Velocity, GraphicsDeviceManager graphic)
        {
            camera = Camera.GetCamRec();
            Sprite.Update(gametime, SpriteVelocity, graphic);
            if (IsInCamera())
                this.SpriteVelocity = new Vector2(this.SpriteVelocity.X, 1);

        }

        protected void StartDirection()
        {
            if (IsLeft)
            {
                SpriteVelocity = new Vector2(-1, 1);

            }
            else
            {
                Sprite.Velocity = new Vector2(1, 1);
            }

        }
        public void SwapVelocity()
        {
            this.SpriteVelocity = new Vector2(this.SpriteVelocity.X * -1, this.SpriteVelocity.Y);
        }
        private bool IsInCamera()
        {
            if (camera.Contains(this.SpritePosition))
            {
                if (!started)
                {
                    this.StartDirection();
                    this.started = true;
                }
                return true;
            }
            return false;
        }

        public override void CollisionResponse(ICollision collided)
        {
            if (collided is MarioCollision)
            {
                MarioCollision(collided.CurrentEntity);
            }
            else if (collided is EnemyCollision)
            {
                EnemyCollision(collided.CurrentEntity as EnemyEntity);
            }
            else if (collided is BlockCollision)
            {
                Rectangle enemyBox = this.BoundBox;
                Rectangle brickBox = collided.CurrentSprite.BoundBox;
                Rectangle intersection = Rectangle.Intersect(enemyBox, brickBox);
                if (enemyBox.Right > brickBox.Left && intersection.Height > intersection.Width
                    || enemyBox.Left > brickBox.Right && intersection.Height > intersection.Width)
                {
                    SideCollision();
                }
                if (enemyBox.Bottom > brickBox.Top && intersection.Height < intersection.Width)
                {
                    TopCollision();
                }

            }
        }

        public void MarioCollision(Entity mario)
        {
            Rectangle enemyBox = this.BoundBox;
            Rectangle marioBox = mario.Sprite.BoundBox;
            Rectangle intersection = Rectangle.Intersect(marioBox, enemyBox);
            //This would have mario kill goomba

            if (marioBox.Bottom > enemyBox.Top && marioBox.Bottom > enemyBox.Bottom && intersection.Height > intersection.Width)
            {
                this.Dead = true;
            }

        }

        public void EnemyCollision(EnemyEntity enemy)
        {
            Rectangle enemy1Box = enemy.BoundBox;
            Rectangle enemy2Box = this.BoundBox;
            Rectangle intersection = Rectangle.Intersect(enemy1Box, enemy2Box);

            if (enemy1Box.Right < enemy2Box.Left)
            {
                this.SwapVelocity();
                enemy.SwapVelocity();
            }

        }


        private void SideCollision()
        {
            this.SpriteVelocity = new Vector2(this.SpriteVelocity.X * -1, this.SpriteVelocity.Y);
        }

        private void TopCollision()
        {
            this.SpriteVelocity = new Vector2(this.SpriteVelocity.X, 0);
        }

    }
    public class GoombaEntity : EnemyEntity
    {
        public GoombaEntity(Vector2 loc) : base(loc)
        {
            Sprite = new WalkingGoomba(loc);
            EntityCollision = new EnemyCollision(this);

            IsLeft = true;
            StartDirection();
        }
    }
    public class GreenKoopaEntity : EnemyEntity
    {
        public GreenKoopaEntity(Vector2 loc, bool left) : base(loc)
        {
            IsLeft = false;
            if (left)
                Sprite = new GreenKoopaWalkingLeft(loc);
            else
                Sprite = new GreenKoopaWalkingRight(loc);

            EntityCollision = new EnemyCollision(this);
            StartDirection();

        }

    }

    public class RedKoopaEntity : EnemyEntity
    {

        public RedKoopaEntity(Vector2 loc, bool left) : base(loc)
        {
            IsLeft = true;
            if (left)
                Sprite = new RedKoopaWalkingLeft(loc);
            else
                Sprite = new RedKoopaWalkingRight(loc);

            EntityCollision = new EnemyCollision(this);
            StartDirection();

        }

    }


}
