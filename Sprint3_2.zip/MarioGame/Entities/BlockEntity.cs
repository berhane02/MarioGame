﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using MarioGame.Interfaces;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MarioGame.Entities
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1012:AbstractTypesShouldNotHaveConstructors")]
    public abstract class BlockEntity:Entity
    {
        public IBlockState BState { get; set; }
        public Vector2 InitialPos { get; set; }
        public IBlockFactory Factory { get; set; }
        public List<Entity> Items { get; set; }//hidden items in blocks

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "loc")]
        protected BlockEntity(Vector2 loc) { }
        public override void Update(GameTime gametime, Vector2 Velocity, GraphicsDeviceManager graphics)
        {
            BState.Update(gametime, graphics);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            BState.Draw(spriteBatch);
        }

        public void BumpTransition()
        {
            BState.BumpTransition();
        }
        public override void AddItems(Entity item, int number, List<Tile> tiles,List<Entity> moving)//only add one for now
        {
            MovingEntities = moving;
            CollideList = tiles;
            Items = new List<Entity>();
            for (int i = 0; i < number; i++)
            {
                Items.Add(item);
            }
        }
        public override void CollisionResponse(ICollision collision)
        {
            BState.CollisionResponse(collision);
        }
    }
}
